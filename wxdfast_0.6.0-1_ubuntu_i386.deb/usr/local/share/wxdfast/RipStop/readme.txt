Copyright (C) 2006, by Erno Szabados chromecat@freemail.hu
See license.txt for conditions on usage.
This is the "Ripstop" icon set for wxdownloads, version 0.2 released at 20061101.
See http://dfast.sourceforge.net
